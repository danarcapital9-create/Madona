#!/usr/bin/env python3
"""Faithful raster trace + precision beveled extrusion of the supplied brand mark.
Dependencies: numpy, Pillow, opencv-python-headless, shapely, mapbox-earcut.
Run: PYTHONPATH=./python-deps python build_monogram.py [logo.png]
The GLB uses XY for the logo, +Y up and +Z as the front, with no axis conversion.
"""
from pathlib import Path
import sys,json,struct,math
import numpy as np
import cv2
from PIL import Image
from shapely.geometry import Polygon
from shapely.geometry.polygon import orient
import mapbox_earcut as earcut
ROOT=Path(__file__).resolve().parent
SOURCE=Path(sys.argv[1]) if len(sys.argv)>1 else Path('/workspace/sites/madonna-lounge/public/brand/logo.png')
im=Image.open(SOURCE).convert('RGB')
a=np.array(im)
# Wordmark begins below row 880. The monogram is the one component above row 820.
mask=(a[:820].min(axis=2)<100).astype(np.uint8)*255
contours,hierarchy=cv2.findContours(mask,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)
hier=hierarchy[0]
outer_index=max((i for i,h in enumerate(hier) if h[3]<0),key=lambda i:cv2.contourArea(contours[i]))
def trace(i):
 return cv2.approxPolyDP(contours[i],0.9,True).reshape(-1,2).astype(float)
out=trace(outer_index)
holes=[trace(i) for i,h in enumerate(hier) if h[3]==outer_index]
all_raw=np.concatenate([out]+holes)
mn=all_raw.min(axis=0);mx=all_raw.max(axis=0);center=(mn+mx)/2
scale=4/(mx[1]-mn[1])
def norm(p):
 q=(p-center)*scale;q[:,1]*=-1;return q
poly=orient(Polygon(norm(out),[norm(p) for p in holes]),sign=1)
if not poly.is_valid:raise ValueError('Invalid source contour: require source repair before modeling')
loops=[np.array(poly.exterior.coords[:-1])]+[np.array(h.coords[:-1]) for h in poly.interiors]
# Normals point out of filled area: exterior CCW, holes CW.
def outline_data(p):
 edge=np.roll(p,-1,axis=0)-p
 tangent=edge/np.linalg.norm(edge,axis=1)[:,None]
 normal=np.stack([tangent[:,1],-tangent[:,0]],axis=1)
 n=normal+np.roll(normal,1,axis=0)
 n/=np.linalg.norm(n,axis=1)[:,None]
 denom=(n*normal).sum(axis=1)
 miter=n/np.maximum(denom[:,None],.24)
 # Locally shrink the planar bevel at the original logo's one-pixel notches.
 # The side silhouette remains exact; short adjoining edges cannot cross.
 edge_lengths=np.linalg.norm(edge,axis=1)
 cap=.34*np.minimum(edge_lengths,np.roll(edge_lengths,1))
 miter*=np.minimum(1,cap/(.0072*np.linalg.norm(miter,axis=1)))[:,None]
 return n,miter,normal
radius=.0072
half_depth=.115
positions=[];normals=[];faces=[[],[]]
def add(points,ns):
 start=len(positions);positions.extend(points);normals.extend(ns);return np.arange(start,start+len(points))
# Face ceramic (material 0), bevels and wall pale champagne ceramic (material 1).
front_coords=[];front_ends=[];front_ids=[];back_ids=[]
for p in loops:
 n,m,edge_normal=outline_data(p);N=len(p)
 sharp=np.sum(edge_normal*np.roll(edge_normal,1,axis=0),axis=1)<math.cos(math.radians(32))
 rings=[]
 profile=[]
 # rear face -> rear bevel -> wall -> front bevel -> front face
 for theta in np.linspace(math.pi/2,0,5):
  profile.append((radius*(1-math.cos(theta)),-half_depth+radius*(1-math.sin(theta)),-math.sin(theta),math.cos(theta)))
 for theta in np.linspace(0,math.pi/2,5):
  profile.append((radius*(1-math.cos(theta)),half_depth-radius*(1-math.sin(theta)),math.sin(theta),math.cos(theta)))
 for inset,z,nz,nxy in profile:
  xy=p-m*inset
  pts=np.column_stack([xy,np.full(N,z)])
  ns=np.column_stack([n*nxy,np.full(N,nz)])
  rings.append(add(pts,ns))
 for k in range(len(rings)-1):
  low,high=rings[k],rings[k+1]
  for j in range(N):
   jj=(j+1)%N
   ni=edge_normal[j] if sharp[j] else n[j]
   nj=edge_normal[j] if sharp[jj] else n[jj]
   ids=[low[j],low[jj],high[jj],high[j]]
   nz0,xy0=profile[k][2:];nz1,xy1=profile[k+1][2:]
   ns=[[ni[0]*xy0,ni[1]*xy0,nz0],[nj[0]*xy0,nj[1]*xy0,nz0],[nj[0]*xy1,nj[1]*xy1,nz1],[ni[0]*xy1,ni[1]*xy1,nz1]]
   q=add([positions[int(i)] for i in ids],ns)
   faces[1].extend([[int(q[0]),int(q[1]),int(q[2])],[int(q[0]),int(q[2]),int(q[3])]])
 # Front and rear faces have separate normals/material vertices to keep planar reflections.
 xy=p-m*radius
 front_coords.extend(xy);front_ends.append(len(front_coords))
 front_ids.extend(add(np.column_stack([xy,np.full(N,half_depth)]),np.tile([0,0,1],(N,1))))
 back_ids.extend(add(np.column_stack([xy,np.full(N,-half_depth)]),np.tile([0,0,-1],(N,1))))
coords=np.array(front_coords)
ends=np.array(front_ends,dtype=np.uint32)
tri=earcut.triangulate_float64(coords,ends).reshape(-1,3)
for t in tri:
 faces[0].append([int(front_ids[i]) for i in t])
 faces[0].append([int(back_ids[i]) for i in t[::-1]])
P=np.array(positions,dtype=np.float32);N=np.array(normals,dtype=np.float32)
F=[np.array(f,dtype=np.uint32) for f in faces]
# Deduplicate complete position/normal tuples, retaining crisp intentional cusps.
used=np.unique(np.concatenate(F).reshape(-1))
packed=np.round(np.column_stack([P[used],N[used]]),7)
unique, inverse=np.unique(packed,axis=0,return_inverse=True)
remap=np.zeros(len(P),dtype=np.uint32);remap[used]=inverse
P=unique[:,:3].astype(np.float32);N=unique[:,3:].astype(np.float32)
F=[remap[f] for f in F]
# Validate polygon inset and triangle area to ensure holes were not filled.
inset_poly=Polygon(coords[:ends[0]],[coords[ends[i-1]:ends[i]] for i in range(1,len(ends))])

from shapely.validation import explain_validity
print('INSET', explain_validity(inset_poly),flush=True)
assert inset_poly.is_valid,'Bevel inset self-intersects'
area=sum(abs(np.linalg.det(np.stack([coords[t[1]]-coords[t[0]],coords[t[2]]-coords[t[0]]])))/2 for t in tri)
assert abs(area-inset_poly.area)<1e-6
np.savez_compressed(ROOT/'monogram-mesh.npz',positions=P,normals=N,face_triangles=F[0],edge_triangles=F[1])
# Minimal glTF 2.0 writer: no textures, no dependencies in exported runtime asset.
buffers=[];views=[];accessors=[];offset=0
def accessor(arr,ctype,kind,minimum=None,maximum=None,target=None):
 global offset
 raw=arr.tobytes();pad=(-len(raw))%4
 vi=len(views);view={'buffer':0,'byteOffset':offset,'byteLength':len(raw)}
 if target:view['target']=target
 views.append(view);buffers.append(raw+b'\0'*pad);offset+=len(raw)+pad
 ai=len(accessors);acc={'bufferView':vi,'componentType':ctype,'count':len(arr),'type':kind}
 if minimum is not None:acc['min']=minimum;acc['max']=maximum
 accessors.append(acc);return ai
pa=accessor(P,5126,'VEC3',P.min(axis=0).tolist(),P.max(axis=0).tolist(),34962)
na=accessor(N,5126,'VEC3',target=34962)
primitives=[]
for mat,fac in enumerate(F):
 idx=fac.reshape(-1).astype(np.uint16)
 ia=accessor(idx,5123,'SCALAR',target=34963)
 primitives.append({'attributes':{'POSITION':pa,'NORMAL':na},'indices':ia,'material':mat})
def srgb(c):
 c=np.array(c)/255;return np.where(c<=.04045,c/12.92,((c+.055)/1.055)**2.4).tolist()
materials=[
 {'name':'Warm ivory ceramic — face','pbrMetallicRoughness':{'baseColorFactor':srgb([232,220,199])+[1],'metallicFactor':0.06,'roughnessFactor':0.29},'extensions':{'KHR_materials_clearcoat':{'clearcoatFactor':.20,'clearcoatRoughnessFactor':.24}}},
 {'name':'Pale champagne satin — rounded rim and sides','pbrMetallicRoughness':{'baseColorFactor':srgb([199,182,151])+[1],'metallicFactor':0.28,'roughnessFactor':0.32},'extensions':{'KHR_materials_clearcoat':{'clearcoatFactor':.12,'clearcoatRoughnessFactor':.30}}}
]
doc={'asset':{'version':'2.0','generator':'Madonna original-logo raster trace / rounded profile extrusion'},'extensionsUsed':['KHR_materials_clearcoat'],'scene':0,'scenes':[{'nodes':[0]}],'nodes':[{'name':'Madonna original intertwined monogram','mesh':0}],'meshes':[{'name':'Precision beveled brand emblem','primitives':primitives}],'materials':materials,'buffers':[{'byteLength':offset}],'bufferViews':views,'accessors':accessors}
j=json.dumps(doc,separators=(',',':'),ensure_ascii=True).encode();j+=b' '*((-len(j))%4)
b=b''.join(buffers)
glb=struct.pack('<4sII',b'glTF',2,12+8+len(j)+8+len(b))+struct.pack('<I4s',len(j),b'JSON')+j+struct.pack('<I4s',len(b),b'BIN\0')+b
(ROOT/'madonna-monogram.glb').write_bytes(glb)
# Save reproducible traced SVG in original pixel frame (only upper mark).
paths=[]
for p in [out]+holes:
 q=p-mn+2
 paths.append('M '+' L '.join(f'{x:.2f},{y:.2f}' for x,y in q)+' Z')
svg=f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {mx[0]-mn[0]+4:g} {mx[1]-mn[1]+4:g}"><path d="{" ".join(paths)}" fill="#073d2b" fill-rule="evenodd"/></svg>'
(ROOT/'monogram-trace.svg').write_text(svg)
info={'source':str(SOURCE),'source_size_px':list(im.size),'source_monogram_bbox_px':list(map(int,[*mn,*mx])),'tracing_max_deviation_px':.9,'components':1,'preserved_holes':len(holes),'contour_vertices':sum(map(len,loops)),'dimensions':[float(v) for v in P.max(axis=0)-P.min(axis=0)],'vertex_count':len(P),'triangle_count':sum(len(f) for f in F),'glb_bytes':len(glb),'front_axis':'+Z','up_axis':'+Y','bevel_radius':radius,'bevel_segments':4,'materials':[m['name'] for m in materials],'source_shape_area':poly.area,'inset_face_area':inset_poly.area}
(ROOT/'model-info.json').write_text(json.dumps(info,indent=2))
print(json.dumps(info,indent=2))
