# Madonna Beauty Lounge — original monogram in 3D

The upper monogram is traced from the supplied 1480 × 1357 logo PNG. The MADONNA / BEAUTY LOUNGE wordmark is excluded. The one connected silhouette and all six enclosed negative spaces are retained.

Runtime asset: `madonna-monogram.glb`.
Transparent path-traced fallback: `madonna-monogram-studio.webp` (PNG also supplied).

## Geometry contract

- XY plane; +Y is upright and +Z is the front.
- Centered at the origin. Bounding dimensions: 4.563953 × 4 × 0.23.
- One aligned object with two material primitives: warm ivory ceramic face and pale champagne satin bevel/sidewall.
- Four segments on each rounded front/rear bevel, radius 0.0072. The planar bevel narrows only at minute source notches to prevent overlaps; the side silhouette stays on the source contour.
- Acute corners have split normals; curved outlines use smooth normals.
- No textures, external resources, lights, cameras, or animation in the GLB.
- 5,900 triangles; 3,364 indexed position/normal tuples; 117,920 bytes.

## Reproduction

From this directory, install `requirements.txt`, then run:

```sh
python build_monogram.py /path/to/original/logo.png
python validate_monogram.py
RENDER_SIZE=1400 RENDER_SAMPLES=192 python render_monogram.py
```

`monogram-trace.svg` is the exact simplified contour used for geometry. `monogram-mesh.npz` and the two PLY files contain the same mesh for validation and studio rendering. The preview uses the CPU Mitsuba path tracer with soft studio area lights and a transparent film. It is a render of actual extrusion geometry.

Blender was unavailable in the execution environment. `blender_project.py` can create a native `.blend` with the model and studio setup when run in Blender 4 or later. The shipped GLB and render do not require Blender.

`model-info.json` and `validation.json` record source bounds, dimensions, counts, silhouette comparison, and topology checks. QA composites on cream and green are included only for visual inspection.

The WebP uses exact lossless encoding and is pixel-identical to the PNG. Fully transparent pixels have zero RGB to avoid lossy-codec padding artifacts in direct inspection. The native antialiased alpha contains all 256 alpha levels. `transparency-validation.json` records these checks.
