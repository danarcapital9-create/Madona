"""Optional Blender-native project builder.
Run with Blender 4+: blender --background --python blender_project.py
Blender is not required for the shipped GLB or Mitsuba preview.
"""
import bpy
from pathlib import Path
from mathutils import Vector
ROOT=Path(__file__).resolve().parent
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
bpy.ops.import_scene.gltf(filepath=str(ROOT/'madonna-monogram.glb'))
# glTF's +Y up becomes Blender +Z, and glTF +Z front becomes Blender -Y.
obj=[o for o in bpy.context.scene.objects if o.type=='MESH'][0]
obj.name='Madonna original interwoven monogram'
world=bpy.data.worlds.new('Soft studio') if not bpy.context.scene.world else bpy.context.scene.world
bpy.context.scene.world=world;world.use_nodes=True
world.node_tree.nodes['Background'].inputs[0].default_value=(.32,.34,.36,1)
world.node_tree.nodes['Background'].inputs[1].default_value=.32
for name,location,power,size in [('Key',(-3.4,-5.2,4.5),650,5),('Fill',(4,-4.5,1.5),250,4),('Rim',(2.2,2,4),450,3)]:
 data=bpy.data.lights.new(name,'AREA');data.energy=power;data.shape='DISK';data.size=size
 light=bpy.data.objects.new(name,data);bpy.context.collection.objects.link(light)
 light.location=location;light.rotation_euler=(Vector((0,0,0))-light.location).to_track_quat('-Z','Y').to_euler()
bpy.ops.object.camera_add(location=(1.7,-10,.52));cam=bpy.context.object
cam.rotation_euler=(Vector((0,0,0))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=5.4
scene=bpy.context.scene;scene.camera=cam;scene.render.engine='CYCLES';scene.cycles.samples=128
scene.render.film_transparent=True;scene.render.resolution_x=1400;scene.render.resolution_y=1400
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'madonna-monogram.blend'))
