from pathlib import Path
import numpy as np,cv2,trimesh,json
from PIL import Image
R=Path(__file__).resolve().parent
info=json.loads((R/'model-info.json').read_text())
a=np.load(R/'monogram-mesh.npz');P=a['positions'];N=a['normals'];F=np.concatenate([a['face_triangles'],a['edge_triangles']]);m=trimesh.Trimesh(P,F,process=True)
cr=np.cross(P[F[:,1]]-P[F[:,0]],P[F[:,2]]-P[F[:,0]])
report={'watertight':bool(m.is_watertight),'winding_consistent':bool(m.is_winding_consistent),'outward_normals':bool(np.all(np.sum(cr*np.mean(N[F],axis=1),axis=1)>0)),'volume':float(m.volume),'genus':int((2-m.euler_number)/2)}
im=np.array(Image.open(info['source']).convert('RGB'))
mask=(im[:820].min(axis=2)<100).astype(np.uint8)
contours,hierarchy=cv2.findContours(mask,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)
h=hierarchy[0];i=max((i for i,x in enumerate(h) if x[3]<0),key=lambda k:cv2.contourArea(contours[k]))
ids=[i]+[k for k,x in enumerate(h) if x[3]==i]
traced=np.zeros_like(mask)
for k in ids:
 approx=cv2.approxPolyDP(contours[k],.9,True)
 cv2.fillPoly(traced,[approx],1 if k==i else 0)
# cv2 hole fill erases one boundary pixel; use even-odd contour drawing for unbiased parity.
selected=[cv2.approxPolyDP(contours[k],.9,True) for k in ids]
traced[:]=0;cv2.drawContours(traced,selected,-1,1,cv2.FILLED)
report['source_silhouette_iou']=float(np.count_nonzero(mask&traced)/np.count_nonzero(mask|traced))
report['shape_difference_pixels']=int(np.count_nonzero(mask!=traced))
report['source_pixels']=int(np.count_nonzero(mask))
(R/'validation.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
# source crop with transparent background for direct geometry audit.
rgba=np.zeros((820,im.shape[1],4),dtype=np.uint8);rgba[:,:,:3]=[7,53,37];rgba[:,:,3]=mask*255
Image.fromarray(rgba).crop((340,76,1158,798)).save(R/'original-monogram-crop.png')
