#!/usr/bin/env python3
"""CPU path-traced studio preview of the exact GLB geometry, using Mitsuba 3.
Run with PYTHONPATH=./python-deps python render_monogram.py
No SVG/raster illusion is used: the renderer reads the same vertices and normals.
"""
from pathlib import Path
import numpy as np,json,os
import mitsuba as mi
from PIL import Image
ROOT=Path(__file__).resolve().parent
mi.set_variant('scalar_rgb')
a=np.load(ROOT/'monogram-mesh.npz');P=a['positions'];N=a['normals']
for name,key in [('ceramic','face_triangles'),('champagne','edge_triangles')]:
 F=a[key]
 header=f'ply\nformat binary_little_endian 1.0\nelement vertex {len(P)}\nproperty float x\nproperty float y\nproperty float z\nproperty float nx\nproperty float ny\nproperty float nz\nelement face {len(F)}\nproperty list uchar int vertex_indices\nend_header\n'.encode()
 verts=np.column_stack([P,N]).astype('<f4')
 faces=np.empty(len(F),dtype=[('count','u1'),('indices','<i4',(3,))]);faces['count']=3;faces['indices']=F
 (ROOT/f'{name}.ply').write_bytes(header+verts.tobytes()+faces.tobytes())
T=mi.ScalarTransform4f
def lin(rgb):
 c=np.array(rgb)/255.;return np.where(c<=.04045,c/12.92,((c+.055)/1.055)**2.4).tolist()
def area(origin,radiance,size):
 return {'type':'rectangle','to_world':T.look_at(origin=origin,target=[0,0,0],up=[0,1,0]) @ T.scale([size[0],size[1],1]),'emitter':{'type':'area','radiance':{'type':'rgb','value':radiance}}}
scene={
 'type':'scene',
 'integrator':{'type':'path','max_depth':5,'hide_emitters':True},
 'sensor':{'type':'orthographic','to_world':T.look_at(origin=[1.7,.52,10],target=[0,0,0],up=[0,1,0]) @ T.scale([2.7,2.7,1]),'sampler':{'type':'independent','sample_count':int(os.getenv('RENDER_SAMPLES','48'))},'film':{'type':'hdrfilm','width':int(os.getenv('RENDER_SIZE','1400')),'height':int(os.getenv('RENDER_SIZE','1400')),'pixel_format':'rgba','rfilter':{'type':'tent'}}},
 'ambient':{'type':'constant','radiance':{'type':'rgb','value':[.32,.34,.36]}},
 'key':area([-3.4,4.5,5.2],[5.8,5.5,4.9],[2.4,3.5]),
 'fill':area([4,1.5,4.5],[1.7,1.85,2.05],[2.5,3.1]),
 'rim':area([2.2,4.0,-2],[3.0,2.8,2.5],[1.5,2]),
 'ceramic':{'type':'ply','filename':str(ROOT/'ceramic.ply'),'face_normals':os.getenv('FLAT_NORMALS')=='1','bsdf':{'type':'principled','base_color':{'type':'rgb','value':lin([232,220,199])},'roughness':.29,'metallic':.06,'clearcoat':.20,'clearcoat_gloss':.75}},
 'champagne':{'type':'ply','filename':str(ROOT/'champagne.ply'),'face_normals':os.getenv('FLAT_NORMALS')=='1','bsdf':{'type':'principled','base_color':{'type':'rgb','value':lin([199,182,151])},'roughness':.32,'metallic':.28,'clearcoat':.12,'clearcoat_gloss':.65}}
}
print('Loading scene and rendering',os.getenv('RENDER_SIZE','1400')+'px /',os.getenv('RENDER_SAMPLES','48'),'samples',flush=True)
img=mi.render(mi.load_dict(scene))
x=np.array(img)
print('RENDERED',x.shape,'alpha',float(x[:,:,3].min()),float(x[:,:,3].max()),flush=True)
# Compress highlights gently, then use standard sRGB display transfer.
alpha=x[:,:,3:4].clip(0,1)
rgb=np.maximum(x[:,:,:3],0)
# Mitsuba RGBA stores coverage-premultiplied output; unpremultiply for PNG.
rgb=np.where(alpha>1e-6,rgb/np.maximum(alpha,1e-6),0)
# Filmic shoulder, using a mild exposure and ACES fit.
rgb*=.68
rgb=(rgb*(2.51*rgb+.03))/(rgb*(2.43*rgb+.59)+.14)
rgb=np.where(rgb<=.0031308,12.92*rgb,1.055*np.maximum(rgb,0)**(1/2.4)-.055)
rgba=np.concatenate([rgb.clip(0,1),alpha],axis=2)
pixels=np.round(rgba*255).astype(np.uint8)
# Preserve a clean straight-alpha asset even in viewers inspecting hidden RGB.
pixels[:,:,:3][pixels[:,:,3]==0]=0
image=Image.fromarray(pixels,'RGBA')
image.save(ROOT/'madonna-monogram-studio.png',optimize=True)
image.save(ROOT/'madonna-monogram-studio.webp',lossless=True,exact=True,quality=100,method=6)
# QA sheets are opaque and are not intended as the web fallback.
for bg,name in [((247,244,237,255),'cream'),((7,42,34,255),'green')]:
 plate=Image.new('RGBA',image.size,bg);plate.alpha_composite(image)
 plate.convert('RGB').resize((900,900)).save(ROOT/f'preview-on-{name}.jpg',quality=94)
print('Saved transparent PNG + WebP and two visual QA compositions',flush=True)
